# MS Validation — Microservicio de Validación de Datos

## HU-02: Validación de estructura del dataset

**Historia de Usuario:**
> Como sistema quiero validar la estructura del dataset para asegurar consistencia de la información.

---

## Responsabilidades

- Recibir un archivo CSV y ejecutar un pipeline de validación estructural
- Verificar extensión, contenido, filas, columnas requeridas y presencia de datos
- Retornar una respuesta estructurada con éxito o lista de errores

---

## Arquitectura bajo principios SOLID

| Principio | Aplicación |
|-----------|-----------|
| **SRP** | Cada validador tiene una única responsabilidad |
| **OCP** | Nuevos validadores se agregan sin modificar los existentes |
| **ISP** | La interfaz `ValidadorCSV` define solo `validar()` |
| **DIP** | El controlador depende de `ServicioCSVBase`, no del servicio concreto |

---

## Estructura del proyecto

```
ms-validation/
├── app/
│   ├── main.py                          # Punto de entrada FastAPI
│   ├── schemas/
│   │   └── upload_response.py           # DTO UploadResponse (ok / fallo)
│   ├── validator/
│   │   ├── base.py                      # Interfaz abstracta ValidadorCSV
│   │   └── validadores.py               # 5 validadores concretos
│   ├── service/
│   │   ├── base.py                      # Interfaz abstracta ServicioCSVBase
│   │   └── validation_service.py        # Servicio concreto con pipeline
│   ├── controllers/
│   │   └── validation_controller.py     # Orquestación
│   └── routes/
│       └── validation_router.py         # Endpoints
├── requirements.txt
├── Dockerfile
└── README.md
```

---

## Pipeline de validación (5 validadores)

| # | Validador | Regla |
|---|-----------|-------|
| 1 | `ValidadorExtension` | El archivo debe tener extensión `.csv` |
| 2 | `ValidadorContenidoNoVacio` | El archivo no debe tener 0 bytes |
| 3 | `ValidadorTieneFilas` | Debe contener al menos una fila |
| 4 | `ValidadorColumnasRequeridas` | Debe tener: `municipio`, `poblacion`, `ingreso_promedio`, `nivel_educativo`, `num_negocios` |
| 5 | `ValidadorTieneDatos` | Debe haber datos reales además del encabezado |

---

## Endpoints

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/health` | Estado del servicio |
| POST | `/validation/validate` | Validar un archivo CSV |

---

## Cómo ejecutar

### Local
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8002
```

### Docker
```bash
docker build -t ms-validation .
docker run -p 8002:8002 ms-validation
```

---

## Entregable demostrable

- Validación integrada: subir CSV válido → respuesta exitosa
- Subir CSV inválido → lista de errores específicos
- Endpoint `/health` funcional
