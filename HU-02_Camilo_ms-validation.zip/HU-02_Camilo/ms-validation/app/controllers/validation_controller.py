from fastapi import UploadFile
from app.service.validation_service import ValidationService

service = ValidationService()


def validar_dataset(file: UploadFile):
    result = service.procesar_csv(file)
    return {
        "success": result.success,
        "data": {
            "file_name": result.file_name,
            "message": result.message,
            "errors": result.errors,
        },
        "error": None if result.success else result.message,
        "trace_id": result.trace_id
    }
