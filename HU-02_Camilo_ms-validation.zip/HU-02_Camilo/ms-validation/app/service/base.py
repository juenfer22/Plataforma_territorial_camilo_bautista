from abc import ABC, abstractmethod
from fastapi import UploadFile
from app.schemas.upload_response import UploadResponse


class ServicioCSVBase(ABC):
    """
    Interfaz abstracta del servicio de validación.
    Define el contrato procesar_csv() que debe implementar cualquier servicio.
    Permite que el controlador no dependa del servicio concreto, aplicando DIP.
    """

    @abstractmethod
    def procesar_csv(self, file: UploadFile) -> UploadResponse:
        pass
