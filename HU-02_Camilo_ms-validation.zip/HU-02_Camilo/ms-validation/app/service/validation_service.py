import uuid
import pandas as pd
from fastapi import UploadFile
from app.service.base import ServicioCSVBase
from app.schemas.upload_response import UploadResponse
from app.validator.validadores import (
    ValidadorExtension,
    ValidadorContenidoNoVacio,
    ValidadorTieneFilas,
    ValidadorColumnasRequeridas,
    ValidadorTieneDatos,
)


class ValidationService(ServicioCSVBase):
    """
    Servicio concreto que ejecuta el pipeline de validación sobre un archivo CSV.
    Aplica los 5 validadores en secuencia y devuelve un UploadResponse.
    """

    def __init__(self):
        self.validadores = [
            ValidadorExtension(),
            ValidadorContenidoNoVacio(),
            ValidadorTieneFilas(),
            ValidadorColumnasRequeridas(),
            ValidadorTieneDatos(),
        ]

    def procesar_csv(self, file: UploadFile) -> UploadResponse:
        trace_id = str(uuid.uuid4())
        errores = []

        # Validar extensión antes de intentar leer
        error_ext = self.validadores[0].validar(None, file.filename)
        if error_ext:
            return UploadResponse.fallo(file.filename, [error_ext], trace_id)

        # Intentar leer el CSV
        try:
            df = pd.read_csv(file.file)
        except Exception as e:
            return UploadResponse.fallo(file.filename, [f"No se pudo leer el archivo: {str(e)}"], trace_id)

        # Ejecutar el resto de validadores
        for validador in self.validadores[1:]:
            error = validador.validar(df, file.filename)
            if error:
                errores.append(error)

        if errores:
            return UploadResponse.fallo(file.filename, errores, trace_id)

        return UploadResponse.ok(file.filename, trace_id)
