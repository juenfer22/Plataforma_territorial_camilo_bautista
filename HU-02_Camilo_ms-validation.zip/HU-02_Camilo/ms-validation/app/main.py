from fastapi import FastAPI
from app.routes import validation_router

app = FastAPI(
    title="MS Validation - Microservicio de Validación de Datos",
    description="Microservicio responsable de validar la estructura de datasets CSV antes del procesamiento.",
    version="1.0.0"
)

app.include_router(validation_router.router)

@app.get("/health")
def health_check():
    return {"status": "ok", "service": "ms-validation"}
