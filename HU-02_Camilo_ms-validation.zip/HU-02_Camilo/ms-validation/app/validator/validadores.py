import os
from typing import Optional
import pandas as pd
from app.validator.base import ValidadorCSV

COLUMNAS_REQUERIDAS = ["municipio", "poblacion", "ingreso_promedio", "nivel_educativo", "num_negocios"]


class ValidadorExtension(ValidadorCSV):
    """Revisa que el archivo tenga extensión .csv"""

    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        if not file_name.lower().endswith(".csv"):
            return f"El archivo '{file_name}' no tiene extensión .csv válida."
        return None


class ValidadorContenidoNoVacio(ValidadorCSV):
    """Revisa que el archivo no tenga 0 bytes (no esté vacío)."""

    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        if df.empty and len(df.columns) == 0:
            return "El archivo está vacío (0 bytes o sin contenido)."
        return None


class ValidadorTieneFilas(ValidadorCSV):
    """Revisa que el archivo tenga al menos una fila."""

    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        if len(df) == 0:
            return "El archivo no contiene ninguna fila de datos."
        return None


class ValidadorColumnasRequeridas(ValidadorCSV):
    """
    Revisa que estén las columnas obligatorias:
    municipio, poblacion, ingreso_promedio, nivel_educativo, num_negocios.
    """

    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        columnas_presentes = [c.lower().strip() for c in df.columns]
        faltantes = [col for col in COLUMNAS_REQUERIDAS if col not in columnas_presentes]
        if faltantes:
            return f"Faltan columnas requeridas: {', '.join(faltantes)}."
        return None


class ValidadorTieneDatos(ValidadorCSV):
    """Revisa que haya filas de datos además del encabezado (al menos 1 fila con datos reales)."""

    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        df_limpio = df.dropna(how="all")
        if len(df_limpio) < 1:
            return "El archivo solo tiene encabezado pero no contiene datos."
        return None
