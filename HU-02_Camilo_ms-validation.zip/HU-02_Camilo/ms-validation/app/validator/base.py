from abc import ABC, abstractmethod
from typing import Optional
import pandas as pd


class ValidadorCSV(ABC):
    """
    Interfaz abstracta que deben cumplir todos los validadores.
    Define el contrato mínimo: un método validar() que retorna
    un mensaje de error o None si todo está bien.

    Aplica los principios ISP (Interface Segregation) y DIP (Dependency Inversion).
    """

    @abstractmethod
    def validar(self, df: pd.DataFrame, file_name: str = "") -> Optional[str]:
        """
        Valida una condición específica sobre el DataFrame.
        :return: mensaje de error si falla, None si es válido.
        """
        pass
