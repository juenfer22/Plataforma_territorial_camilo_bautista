from fastapi import APIRouter, UploadFile, File
from app.controllers.validation_controller import validar_dataset

router = APIRouter(prefix="/validation", tags=["Validación de Datos"])


@router.post("/validate", summary="Validar estructura de dataset CSV")
async def validate_dataset(file: UploadFile = File(...)):
    """
    HU-02: Como sistema quiero validar la estructura del dataset
    para asegurar consistencia de la información.

    Ejecuta el pipeline de 5 validadores:
    1. Extensión .csv
    2. Contenido no vacío
    3. Tiene filas
    4. Columnas requeridas (municipio, poblacion, ingreso_promedio, nivel_educativo, num_negocios)
    5. Tiene datos reales más allá del encabezado
    """
    return validar_dataset(file)
