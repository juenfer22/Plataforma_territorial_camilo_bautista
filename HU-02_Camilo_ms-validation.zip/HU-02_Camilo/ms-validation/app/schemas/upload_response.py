from pydantic import BaseModel
from typing import Optional


class UploadResponse(BaseModel):
    success: bool
    message: str
    file_name: Optional[str] = None
    errors: Optional[list[str]] = None
    trace_id: Optional[str] = None

    @classmethod
    def ok(cls, file_name: str, trace_id: str = None):
        """Constructor para respuesta exitosa."""
        return cls(
            success=True,
            message="Archivo válido. Listo para procesamiento.",
            file_name=file_name,
            errors=None,
            trace_id=trace_id
        )

    @classmethod
    def fallo(cls, file_name: str, errors: list[str], trace_id: str = None):
        """Constructor para respuesta con errores de validación."""
        return cls(
            success=False,
            message="El archivo no pasó la validación.",
            file_name=file_name,
            errors=errors,
            trace_id=trace_id
        )
